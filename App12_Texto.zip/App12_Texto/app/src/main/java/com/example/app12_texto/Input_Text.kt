package com.example.app12_texto

import android.os.Bundle
import android.widget.CheckBox
import androidx.appcompat.app.AppCompatActivity
import com.example.app12_texto.databinding.ActivityInputTextBinding
import com.google.android.material.checkbox.MaterialCheckBox
import android.widget.LinearLayout
class Input_Text : AppCompatActivity() {

private lateinit var binding: ActivityInputTextBinding
    private var isUpdatingChildren = false
    private lateinit var checkBoxParent: MaterialCheckBox
    private lateinit var childrenCheckBoxes: List<MaterialCheckBox>


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInputTextBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Inicializar MaterialCheckBox y LinearLayout
        checkBoxParent = findViewById(R.id.checkbox_parent)
        val checkboxContainer = findViewById<LinearLayout>(R.id.checkbox_container)
        childrenCheckBoxes = listOf(
            findViewById(R.id.checkbox_child_1),
            findViewById(R.id.checkbox_child_2),
            findViewById(R.id.checkbox_child_3),
            findViewById(R.id.checkbox_child_4)
        )

        // Parent's checked state changed listener
        val parentOnCheckedStateChangedListener =
            MaterialCheckBox.OnCheckedStateChangedListener { checkBox: MaterialCheckBox, state: Int ->
                val isChecked=checkBox.isChecked
                if (state != MaterialCheckBox.STATE_INDETERMINATE) {
                    isUpdatingChildren=true
                    for (child in childrenCheckBoxes) {
                        child.isChecked=isChecked
                    }
                    isUpdatingChildren=false
                }
            }
        checkBoxParent.addOnCheckedStateChangedListener(parentOnCheckedStateChangedListener)

        // Checked state changed listener for each child
        val childOnCheckedStateChangedListener =
            MaterialCheckBox.OnCheckedStateChangedListener { checkBox: MaterialCheckBox?, state: Int ->
                if (!isUpdatingChildren) {
                    setParentState(
                        checkBoxParent,
                        childrenCheckBoxes,
                        parentOnCheckedStateChangedListener
                    )
                }
            }
        for (child in childrenCheckBoxes) {
            (child as MaterialCheckBox)
                .addOnCheckedStateChangedListener(childOnCheckedStateChangedListener)
        }

        // Set first child to be checked
        childrenCheckBoxes.first().isChecked = true
        // Set parent's state
        setParentState(checkBoxParent, childrenCheckBoxes, parentOnCheckedStateChangedListener)



    }

    private fun setParentState(
        checkBoxParent: MaterialCheckBox,
        childrenCheckBoxes: List<CheckBox>,
        parentOnCheckedStateChangedListener: MaterialCheckBox.OnCheckedStateChangedListener
    ) {
        val checkedCount = childrenCheckBoxes.stream().filter { obj: CheckBox -> obj.isChecked }
            .count()
            .toInt()
        val allChecked = checkedCount == childrenCheckBoxes.size
        val noneChecked = checkedCount == 0
        checkBoxParent.removeOnCheckedStateChangedListener(parentOnCheckedStateChangedListener)
        if (allChecked) {
            checkBoxParent.isChecked = true
        } else if (noneChecked) {
            checkBoxParent.isChecked = false
        } else {
            checkBoxParent.checkedState = MaterialCheckBox.STATE_INDETERMINATE
        }
        checkBoxParent.addOnCheckedStateChangedListener(parentOnCheckedStateChangedListener)
    }


}